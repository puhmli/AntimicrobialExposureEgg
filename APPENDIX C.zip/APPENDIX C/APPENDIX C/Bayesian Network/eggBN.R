#basic package
library("ggplot2")
library(tidyverse)
library(caret)
install.packages("caretEnsemble", dependencies = TRUE)
library(caretEnsemble)
library(dplyr)
###################################################
#data clean
####################################################
install.packages("readxl")
library(readxl)

#####################################################################################################################################################################################
#CHOOSE DATAFRAME FOR BN
file_path <- "D:EggDataForBN.xlsx"  # 替换为实际路径
eggDATA <- read_excel(file_path)
str(eggDATA)
colnames(eggDATA)
eggDATA_TAN<-cbind(eggDATA$"ProductClass" ,eggDATA$"AnimalSource",eggDATA$"HazardCategory",eggDATA$"Contaminant",
                  eggDATA$"ProdMonth",eggDATA$"ProdYear",eggDATA$"ProdPlace",eggDATA$"FinalMonth",eggDATA$"FinalYear",eggDATA$"SamplingPlace",eggDATA$"SamplingLevel",eggDATA$"ChainPoint")
str(eggDATA_TAN)
is.na(eggDATA_TAN)
eggDATA_TAN<-as.data.frame(eggDATA_TAN)
eggDATA_TAN[is.na(eggDATA_TAN)] <- "ss"
colnames(eggDATA_TAN)<-c("ProductClass","AnimalSource","HazardCategory","Contaminant","ProdM","ProdY","ProdP","FinalM","FinalY","SamplingP","SamplingL","ChainPoint")

eggDATA_TAN <- as.data.frame(unclass(eggDATA_TAN), stringsAsFactors = TRUE)
sapply(eggDATA_TAN, class)

#####################################################################################################################################################################################
#DATA CLEAN
##############
#clean variable ProdP
levels(eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Anhui', '1', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Beijing', '2', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Chongqing', '3', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Fujian', '4', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Gansu', '5', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Guangdong', '6', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Guangxi', '7', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Guizhou', '8', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Hainan', '9', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Hebei', '10', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Heilongjiang', '11', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Henan', '12', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Hubei', '13', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Hunan', '14', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('InnerMongolia', '15', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Jiangsu', '16', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Jiangxi', '17', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Jilin', '18', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Liaoning', '19', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Ningxia', '20', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Qinghai', '21', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Shaanxi', '22', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Shandong', '23', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Shanghai', '24', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Shanxi', '25', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Sichuan', '26', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Tianjin', '27', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Tibet', '28', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('unknown', '29', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Xinjiang', '30', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Yunnan', '31', eggDATA_TAN$ProdP)
eggDATA_TAN$ProdP<- gsub('Zhejiang', '32', eggDATA_TAN$ProdP)

#clean variable contaminant
levels(eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Chloramphenicol', '1', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Ciprofloxacin', '2', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Dimetridazole', '3', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Doxycycline', '4', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Enrofloxacin', '5', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Florfenicol', '6', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('fluoroquinolones', '7', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Furazolidone', '8', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Metronidazole', '9', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Natamycin', '10', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Ofloxacin', '11', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Oxytetracycline', '12', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Pefloxacin', '13', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Rimantadine', '14', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Sarafloxacin', '15', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Sulfamethoxazole', '16', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Thiamphenicol', '17', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Tetracyclines', '18', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Aerobic Plate Count', '19', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Amantadine', '20', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Benzoic Acid', '21', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Clopidol', '22', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Ecoli', '23', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Fipronil', '24', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('inorganic arsenic', '25', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Na', '26', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Pb', '27', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Protein', '28', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Salmonella', '29', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Sorbic acid', '30', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('Thiamethoxam', '31', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('label', '32', eggDATA_TAN$Contaminant)
eggDATA_TAN$Contaminant<- gsub('unknown', '33', eggDATA_TAN$Contaminant)


#####################################################################
#set as factor
eggDATA_TAN <- as.data.frame(unclass(eggDATA_TAN), stringsAsFactors = TRUE)
sapply(eggDATA_TAN, class)
##########################################################
#####select 80% datasets for TAN training
nrow(eggDATA_TAN)
ns<-round(nrow(eggDATA_TAN)*0.8)
set.seed(0)
samp <- sample(nrow(eggDATA_TAN),ns)
egg80 <- eggDATA_TAN[samp,]
egg20 <- eggDATA_TAN[-samp,]
str(egg80 )
str(egg80$antibio)
str(egg80$ProductClass)
str(egg20 )

#####################################################################################################################################################################################
#Building Bayesian network
#####################################################
#bnlearn library
#########################################################
install.packages("bnlearn")
library(bnlearn)
install.packages("BiocManager")
BiocManager::install("Rgraphviz")
library("Rgraphviz")
install.packages("gRbase")
install.packages("gRain")
install.packages("bnclassify")
library("bnclassify")
library("gRbase")
library("gRain")
###########################################################


################################################
#Bayesian structure learning and validation
########################################################################
#
tan = tree.bayes(egg80, "HazardCategory")
fitted = bn.fit(tan, egg80, method = "bayes")
fitted$antibio
str(fitted)
pred = predict(fitted, egg20)
bnclassify::accuracy(pred, egg20$HazardCategory)
table(pred, egg20[, "HazardCategory"]) 
par(mfrow = c(1,1))
graphviz.plot(tan)
cv.nb = bn.cv(data = egg80,tan, runs = 10, method = "k-fold", folds = 10)
##################################################################################
#Check BN performance
confMat <- confusionMatrix(as.factor(pred), as.factor(egg20$HazardCategory))
print(confMat)

##################################################################################
#check structure and variable
str(egg80)
levels(egg80$SamplingP)
levels(egg80$HazardCategory)
levels(egg80$Contaminant)
#################################################################################

##################################################################################
#marginal distribution of each varaible
#####marginal distribution
junction = compile(as.grain(fitted))
ProductClass<-querygrain(junction , nodes = "ProductClass", type = "marginal",
                           evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                           details = 0)
AnimalSource<-querygrain(junction , nodes = "AnimalSource", type = "marginal",
                           evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                           details = 0)
HazardCategory<-querygrain(junction , nodes = "HazardCategory", type = "marginal",
                            evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                            details = 0)
Contaminant<-querygrain(junction , nodes = "Contaminant", type = "marginal",
                          evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                          details = 0)
ProdM<- querygrain(junction , nodes = "ProdM", type = "marginal",
                            evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                            details = 0)
ProdY <- querygrain(junction , nodes = "ProdY", type = "marginal",
                         evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                         details = 0)
FinalM  <- querygrain(junction , nodes = "FinalM", type = "marginal",
                       evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                       details = 0)
FinalY  <- querygrain(junction , nodes = "FinalY", type = "marginal",
                      evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                      details = 0)
ChainPoint  <- querygrain(junction , nodes = "ChainPoint", type = "marginal",
                      evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                      details = 0)
SamplingP  <- querygrain(junction , nodes = "SamplingP", type = "marginal",
                      evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                      details = 0)
SamplingL  <- querygrain(junction , nodes = "SamplingL", type = "marginal",
                      evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                      details = 0)
ProdP <- querygrain(junction , nodes = "ProdP", type = "marginal",
                    evidence = NULL, exclude = TRUE, normalize = TRUE, result = "array",
                    details = 0)

# 编译网络为gRain对象
junction <- compile(as.grain(fitted))

# 获取所有节点名称
node_names <- nodes(fitted)

# 批量计算所有节点的边际概率
marginal_probs <- lapply(node_names, function(node) {
  querygrain(junction, 
             nodes = node, 
             type = "marginal")
})

# 为结果命名
names(marginal_probs) <- node_names

# 打印所有节点的边际概率
for(node in node_names) {
  cat("\nMarginal probabilities for", node, ":\n")
  print(marginal_probs[[node]])
}

################################################################
#test
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Anhui")), method = "ls", n= 10^6)

#########################################################################################################################################
#monitoring at Beijing and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Beijing")), method = "ls", n= 10^6)
#for antibiotic contaminant

for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}
#from individual source for all antibiotic 
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}

#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at beijing contamination from", i))
  print(result)
}

########################################################################################################################################
#monitoring at Anhui and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Anhui")), method = "ls", n= 10^6)
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Anhui contamination from", i))
 print(result)
}
#from individual source for all antibiotic 
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Anhui contamination from", i))
 print(result)
}

#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Beijing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Anhui"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Anhui contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Fujian and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Fujian")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Fujian contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Fujian contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Fujian"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Fujian contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Gansu and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Gansu")), method = "ls", n= 10^6)
#from individual source
for (i in 1:33) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Gansu contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Gansu contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Gansu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Gansu contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Guangdong and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Guangdong")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guangdong contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guangdong contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangdong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangdong contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Guangxi and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Guangxi")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guangxi contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(Contaminant== as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guangxi contamination from", i))
 print(result)
}

set.seed(0)
cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(Contaminant== "1")),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 


##from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Guangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guangxi contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Guizhou and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Guizhou")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guizhou contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Guizhou contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Guizhou"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Guizhou contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Hainan and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Hainan")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hainan contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hainan contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Hainan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hainan contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Hebei and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Hebei")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hebei contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hebei contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Hebei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hebei contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Henan and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Henan")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Henan contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Henan contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Henan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Henan contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Heilongjiang and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Heilongjiang")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Heilongjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Heilongjiang contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Hubei and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Hubei")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hubei contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hubei contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Hubei"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hubei contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Hunan and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Hunan")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hunan contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Hunan contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Hunan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Hunan contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Jilin and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Jilin")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Jilin contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Jilin contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Jilin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jilin contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Jiangsu and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Jiangsu")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangsu"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangsu contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Jiangxi and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Jiangxi")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at beijing contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Jiangxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Jiangxi contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Liaoning and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Liaoning")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Liaoning contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Liaoning contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Liaoning"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Liaoning contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at InnerMongolia and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="InnerMongolia")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="InnerMongolia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at InnerMongolia contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Ningxia and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Ningxia")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Ningxia contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Ningxia contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Ningxia"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Ningxia contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Qinghai and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Qinghai")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Qinghai contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Qinghai contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Qinghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Qinghai contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Shandong and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Shandong")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shandong contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shandong contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Shandong"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shandong contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Shaanxi and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Shaanxi")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Shaanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shaanxi contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Shanxi and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Shanxi")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shanxi contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shanxi contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanxi"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanxi contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Shanghai and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Shanghai")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shanghai contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Shanghai contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Shanghai"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Shanghai contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Sichuan and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Sichuan")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Sichuan contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Sichuan contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Sichuan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Sichuan contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Tibet and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Tibet")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Tibet contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Tibet contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Tibet"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tibet contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Xinjiang and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Xinjiang")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Xinjiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Xinjiang contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Yunnan and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Yunnan")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Yunnan contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Yunnan contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Yunnan"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Yunnan contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Zhejiang and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Zhejiang")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:19) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Zhejiang"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Zhejiang contamination from", i))
  print(result)
}
########################################################################################################################################
#monitoring at Chongqing and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Chongqing")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Chongqing contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Chongqing contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Chongqing"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Chongqing contamination from", i))
  print(result)
}
##########################################################################################
########################################################################################################################################
#monitoring at Tianjin and check all contamination source places#########################################################################
set.seed(0)
cpquery(fitted, event =((HazardCategory == "Antibiotic")),evidence=((SamplingP=="Tianjin")), method = "ls", n= 10^6)
#from individual source
for (i in 1:32) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((HazardCategory == "Antibiotic")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Tianjin contamination from", i))
 print(result)
}
#for antibiotic contaminant
for (i in 1:18) {
 as.factor(i)
 set.seed(0)
 prob= cpquery(fitted, event = ((Contaminant== as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
 result<- c(prob, paste("monitoring at Tianjin contamination from", i))
 print(result)
}
#from individual source for all antibiotic for ('Chloramphenicol', '1')/('Ciprofloxacin', '2')/('Dimetridazole', '3')
#('Chloramphenicol', '1')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "1")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Ciprofloxacin', '2')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "2")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}

#('Dimetridazole', '3')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "3")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Doxycycline', '4')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "4")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Enrofloxacin', '5')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "5")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Florfenicol', '6')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "6")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Furazolidone', '8')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "8")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}

#('Metronidazole', '9')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "9")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Ofloxacin', '11')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "11")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Sulfamethoxazole', '16')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "16")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}
#('Thiamphenicol', '17')
for (i in 1:32) {
  as.factor(i)
  set.seed(0)
  prob= cpquery(fitted, event = ((Contaminant == "17")&(ProdP == as.character(i))),evidence=(SamplingP=="Tianjin"),method = "ls", n= 10^6) 
  result<- c(prob, paste("monitoring at Tianjin contamination from", i))
  print(result)
}


#####################################################################################################################################
#conditional probability of antibio agents#########################################################################
levels(egg80$Contaminant)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Amantadine")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Dimetridazole")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Doxycycline")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Enrofloxacin")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Frontline")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Furazolidone")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Levofloxacin")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Metronidazole")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Ofloxacin")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Sulfamethoxazole")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
set.seed(0)
cpquery(fitted, event =((Contaminant== "Sulfonamides")),evidence=((antibio == "contaminated by antibiotics")), method = "ls", n= 10^6)
##################################################################################################################


# 初始化结果数据框
results_df <- data.frame(
  Contaminant = character(),
  ProdP = character(),
  SamplingP = character(),
  Probability = numeric(),
  stringsAsFactors = FALSE
)

# 设置参数
selected_contaminants <- c("1","2","3","4","5","6","7","8","9","11","16","17")
sampling_places <- levels(egg80$SamplingP)
prod_places <- as.character(1:32)

# 主循环：遍历每种抗生素
for (contaminant in selected_contaminants) {
  total_prob <- 0
  temp_list <- list()
  
  for (prodP in prod_places) {
    for (samplingP in sampling_places) {
      set.seed(0)
      prob <- cpquery(fitted,
                      event = ((ProdP == prodP) & (SamplingP == samplingP)),
                      evidence = (Contaminant == contaminant),
                      method = "ls", n = 10^6)
      
      total_prob <- total_prob + prob
      
      temp_list[[length(temp_list) + 1]] <- data.frame(
        Contaminant = contaminant,
        ProdP = prodP,
        SamplingP = samplingP,
        Probability = prob,
        stringsAsFactors = FALSE
      )
    }
  }
  
  # 归一化：确保每种抗生素的 (i,j) 概率之和为 1
  normalized_df <- do.call(rbind, temp_list)
  normalized_df$Probability <- normalized_df$Probability / total_prob
  
  # 打印当前抗生素分布汇总
  print(paste("Contaminant", contaminant, "Total Probability:", round(sum(normalized_df$Probability), 6)))
  
  # 合并入总结果
  results_df <- rbind(results_df, normalized_df)
}

# 导出为CSV文件
write.csv(results_df, file = "D:/Antibiotic_Origin_Distribution_By_Contaminant.csv", row.names = FALSE)


# 初始化结果数据框
results_df <- data.frame(
  Contaminant = character(),
  ProdP = character(),
  SamplingP = character(),
  Probability = numeric(),
  stringsAsFactors = FALSE
)

# 设置参数
selected_contaminants <- c("19","20","21","22","23","24","25","26","27","28","29","30","31","32","33")
sampling_places <- levels(egg80$SamplingP)
prod_places <- as.character(1:32)

# 主循环：遍历每种抗生素
for (contaminant in selected_contaminants) {
  total_prob <- 0
  temp_list <- list()
  
  for (prodP in prod_places) {
    for (samplingP in sampling_places) {
      set.seed(0)
      prob <- cpquery(fitted,
                      event = ((ProdP == prodP) & (SamplingP == samplingP)),
                      evidence = (Contaminant == contaminant),
                      method = "ls", n = 10^6)
      
      total_prob <- total_prob + prob
      
      temp_list[[length(temp_list) + 1]] <- data.frame(
        Contaminant = contaminant,
        ProdP = prodP,
        SamplingP = samplingP,
        Probability = prob,
        stringsAsFactors = FALSE
      )
    }
  }
  
  # 归一化：确保每种抗生素的 (i,j) 概率之和为 1
  normalized_df <- do.call(rbind, temp_list)
  normalized_df$Probability <- normalized_df$Probability / total_prob
  
  # 打印当前抗生素分布汇总
  print(paste("Contaminant", contaminant, "Total Probability:", round(sum(normalized_df$Probability), 6)))
  
  # 合并入总结果
  results_df <- rbind(results_df, normalized_df)
}

# 导出为CSV文件
write.csv(results_df, file = "D:/Antibiotic_Origin_Distribution_By_Contaminant0930.csv", row.names = FALSE)
